/* ========================================
 * Trinamic TMC2100 Stepper Library 
 * Written By M. Bon for Digikey Electronics
 * Feburary 2017 
 *
 * ========================================
*/

#ifndef  __`$INSTANCE_NAME`_API_H__
    
#define  __`$INSTANCE_NAME`_API_H__


#define true  1 
#define false 0

/* TMC Clock */ 
#define Internal_CLK 0 
#define External_CLK 1 

extern int `$INSTANCE_NAME`_TMC_Clk_EN; //Default to using TMC2100's internal clock

/* Current Sensing */ 
#define Internal_ref_V   0 
#define Internal_sense_R 1
#define External_ref_V   2

extern int `$INSTANCE_NAME`_Current_sensing; 
    
/* MicroStep Resolution */ 
#define Fullstep     1
#define Halfstep     2
#define Quarterstep  4
#define uSteps       16

extern int `$INSTANCE_NAME`_Microsteps; 

#define Interpolation_on  0 
#define Interpolation_off 0
    
extern int `$INSTANCE_NAME`_Interpolation; 
    
#define spreadCycle  0
#define stealthChop  1
    
extern int `$INSTANCE_NAME`_Chopper_mode; 
    
/*Chopper Settings*/ 
#define Hardware_defined 0
#define Software_defined 1 
#define Low     0 
#define Medium  1
#define High    2 

extern int `$INSTANCE_NAME`_Off_time; 
extern int `$INSTANCE_NAME`_Chopper_hysterisis; 
extern int `$INSTANCE_NAME`_Blank_time; 
extern int `$INSTANCE_NAME`_Chopper_define; 
    
/*Standstill Power Down */ 
extern int `$INSTANCE_NAME`_StandStill_power_down;

/*Steps and Step counters*/ 
#define Continous 0 
extern int `$INSTANCE_NAME`_toggles;         //2 * the total steps/microsteps the user wants the motor to move 
extern int `$INSTANCE_NAME`_current_steps;   //Number of steps/microsteps the motor has moved so far 
extern int `$INSTANCE_NAME`_step_period;     //Set time between steps, 1 = 41.6665 nS 
#define LOCK   0
#define UNLOCK 1

/*function definitions*/ 
void `$INSTANCE_NAME`_TMC2100_Stop();
void `$INSTANCE_NAME`_TMC2100_Start(int `$INSTANCE_NAME`_user_steps, int `$INSTANCE_NAME`_StandStill_power_down, int `$INSTANCE_NAME`_step_period, int `$INSTANCE_NAME`_direction); 
void `$INSTANCE_NAME`_TMC2100_Initialize(); 
void `$INSTANCE_NAME`_TMC2100_Config(int `$INSTANCE_NAME`_TMC_Clk_EN,int `$INSTANCE_NAME`_Current_sensing, int `$INSTANCE_NAME`_Microsteps, int `$INSTANCE_NAME`_Interpolation, int `$INSTANCE_NAME`_Chopper_mode);
void `$INSTANCE_NAME`_TMC2100_Chopper_Config(int `$INSTANCE_NAME`_Off_time, int `$INSTANCE_NAME`_Chopper_hysterisis, int `$INSTANCE_NAME`_Blank_time); 
void `$INSTANCE_NAME`_TMC2100_Release(int `$INSTANCE_NAME`_TMC_lock); 
void `$INSTANCE_NAME`_TMC2100_Stop_and_Release(); 
int  `$INSTANCE_NAME`_TMC2100_Degrees_to_Steps(double degrees, int steps_per_revolution, int `$INSTANCE_NAME`_Microsteps); 

    
#endif

/* [] END OF FILE */

