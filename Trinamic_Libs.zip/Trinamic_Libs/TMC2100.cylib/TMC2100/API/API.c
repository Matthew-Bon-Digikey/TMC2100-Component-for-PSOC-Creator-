/* ========================================
 * Trinamic TMC2100 Stepper Library 
 * Written By M. Bon for Digikey Electronics
 * Feburary 2017 
 *
 *
 * ========================================
*/

#include <project.h> 
#include <math.h> 
#include "`$INSTANCE_NAME`_API.h"

/*******************************************************
                  Default Configuration 
********************************************************/
int `$INSTANCE_NAME`_toggles = Continous;                            //defualt to continous steps 
int `$INSTANCE_NAME`_current_steps = 0;                              //default to 0 
int `$INSTANCE_NAME`_step_period = 256;                              //Set time between steps, 1 = 83.333 nS, default to 256 = 42.667 uS, note this is twice the timer period  
int `$INSTANCE_NAME`_TMC_Clk_EN = Internal_CLK;                      //default to TMC2100's internal clock 
int `$INSTANCE_NAME`_StandStill_power_down = true;                   //default to disabled 
int `$INSTANCE_NAME`_Current_sensing = Internal_ref_V;               //default to TMC2100's internal voltage reference 
int `$INSTANCE_NAME`_Microsteps = Fullstep;                          //default to Full steps 
int `$INSTANCE_NAME`_Interpolation = Interpolation_off;              //default to no interpolation
int `$INSTANCE_NAME`_Off_time = Low;                                 //default to 140tclk 
int `$INSTANCE_NAME`_Chopper_hysterisis = Low;                       //default to low setting 
int `$INSTANCE_NAME`_Blank_time = Medium;                            //default to 24 cycles 
int `$INSTANCE_NAME`_Chopper_define = Hardware_defined;              //default to not calling the chopper config function
CY_ISR_PROTO(`$INSTANCE_NAME`_TMC_Timer_Interrupt); 


void `$INSTANCE_NAME`_TMC2100_Stop()
{
   `$INSTANCE_NAME`_TMC_Timer_Stop(); 
   `$INSTANCE_NAME`_isr_TMC_Stop(); //disable interrupt 
    CyDelay(100);//Short delay to ensure that the motor stops
   
}
void `$INSTANCE_NAME`_TMC2100_Release(int `$INSTANCE_NAME`_TMC_lock)
{
    if (`$INSTANCE_NAME`_TMC_lock == UNLOCK)
    {
        `$INSTANCE_NAME`_En_Write(1); //Unlock the motor 
    } 
    else 
    {
        `$INSTANCE_NAME`_En_Write(0); //Lock the motor 
    }
    
}
void `$INSTANCE_NAME`_TMC2100_Stop_and_Release()
{
    `$INSTANCE_NAME`_TMC2100_Stop(); 
    `$INSTANCE_NAME`_TMC2100_Release(UNLOCK); 
}

void `$INSTANCE_NAME`_TMC2100_Start(int `$INSTANCE_NAME`_user_steps, int `$INSTANCE_NAME`_StandStill_power_down, int `$INSTANCE_NAME`_step_period, int `$INSTANCE_NAME`_direction)
{
    `$INSTANCE_NAME`_toggles = `$INSTANCE_NAME`_user_steps*2; 
    //TMC2100_Config(); //Call Configuration function to setup TMC2100  
    
    if (`$INSTANCE_NAME`_StandStill_power_down == true)
    {        
        `$INSTANCE_NAME`_En_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance Digital
    }
    else 
    {
        `$INSTANCE_NAME`_En_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
        `$INSTANCE_NAME`_En_Write(0); //Drive Enable pin Low  
    }  
    
    if (`$INSTANCE_NAME`_direction == Low) 
    {
        `$INSTANCE_NAME`_DIR_Write(0); //Write direction pin low 
        
    }
    
    else 
    {
        `$INSTANCE_NAME`_DIR_Write(1); //Write direction pin High 
    }
    CyDelayUs(1); 
     
    `$INSTANCE_NAME`_isr_TMC_StartEx(`$INSTANCE_NAME`_TMC_Timer_Interrupt); //Enable Interrupt
    
    `$INSTANCE_NAME`_TMC_Timer_Start(); 
    `$INSTANCE_NAME`_TMC_Timer_WritePeriod(`$INSTANCE_NAME`_step_period); //Set timer period, results in the time between steps being twice the timer period 
    `$INSTANCE_NAME`_TMC_Timer_WriteCounter(0);
}

void `$INSTANCE_NAME`_TMC2100_Initialize()
{
    `$INSTANCE_NAME`_TMC2100_Chopper_Config(`$INSTANCE_NAME`_Off_time,`$INSTANCE_NAME`_Chopper_hysterisis,`$INSTANCE_NAME`_Blank_time); 
    `$INSTANCE_NAME`_TMC2100_Config( `$INSTANCE_NAME`_TMC_Clk_EN, `$INSTANCE_NAME`_Current_sensing, `$INSTANCE_NAME`_Microsteps, `$INSTANCE_NAME`_Interpolation, `$INSTANCE_NAME`_Chopper_mode); 
}

void `$INSTANCE_NAME`_TMC2100_Config(int `$INSTANCE_NAME`_TMC_Clk_EN,int `$INSTANCE_NAME`_Current_sensing, int `$INSTANCE_NAME`_Microsteps, int `$INSTANCE_NAME`_Interpolation, int `$INSTANCE_NAME`_Chopper_mode)
{
    `$INSTANCE_NAME`_TMC2100_Stop(); //Stop Stepper so we don't change the configuration while the motor is running 
    
    /*******************************************************
                            Setup Clock 
    ********************************************************/ 
    if (`$INSTANCE_NAME`_TMC_Clk_EN == External_CLK)
    {    
        `$INSTANCE_NAME`_TMC_CLK_Start(); //Enable Clock 
    }
    
    else //Default to internal clock 
    {              
        `$INSTANCE_NAME`_TMC_CLK_Stop(); //Disable external clk 
        //`$INSTANCE_NAME`_T_CLK_Pin_Write(0); //Drive Clk pin to GND   
    }
    
    
    /*******************************************************
                         Setup Current Sensing
    ********************************************************/ 
    if (`$INSTANCE_NAME`_Current_sensing == Internal_ref_V) 
    {   
        `$INSTANCE_NAME`_CFG_3_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
        `$INSTANCE_NAME`_CFG_3_Write(0); //Drive CFG_3 pin Low  
    }
    
    else if (`$INSTANCE_NAME`_Current_sensing == Internal_sense_R)
    {
        `$INSTANCE_NAME`_CFG_3_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
        `$INSTANCE_NAME`_CFG_3_Write(1); //Drive CFG_3 pin High 
    }
    
    else if (`$INSTANCE_NAME`_Current_sensing == External_ref_V)
    {
        `$INSTANCE_NAME`_CFG_3_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital        
    }
    
    else //default to internal_ref_V 
    { 
        `$INSTANCE_NAME`_Current_sensing = Internal_ref_V;
        `$INSTANCE_NAME`_CFG_3_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
        `$INSTANCE_NAME`_CFG_3_Write(0); //Drive CFG_3 pin Low 
    }
    
    
    /*******************************************************
                    Setup Mircostep Resolution
    ********************************************************/
    switch (`$INSTANCE_NAME`_Microsteps) 
     {   
        case Fullstep: 
            {
                `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                `$INSTANCE_NAME`_CFG_1_Write(0); //Drive CFG_1 pin Low 
                `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                `$INSTANCE_NAME`_CFG_2_Write(0); //Drive CFG_2 pin Low 
                break; 
            }
         
        case Halfstep:
            {
                if (`$INSTANCE_NAME`_Interpolation == Interpolation_on)
                {
                    `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital
                    `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_2_Write(0); //Drive CFG_2 pin Low 
                    
                }
                else //Default to interpolation_off 
                {
                    `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_1_Write(1); //Drive CFG_1 pin High 
                    `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_2_Write(0); //Drive CFG_2 pin Low 
                }
                
                break;       
            }
        
        case Quarterstep:
            {
                if (`$INSTANCE_NAME`_Interpolation == Interpolation_on)
                {
                    if (`$INSTANCE_NAME`_Chopper_mode == spreadCycle)
                    {
                        `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital
                        `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                        `$INSTANCE_NAME`_CFG_2_Write(1); //Drive CFG_2 pin High 
                    }
                    
                    else if (`$INSTANCE_NAME`_Chopper_mode == stealthChop)
                    {
                        `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                        `$INSTANCE_NAME`_CFG_1_Write(1); //Drive CFG_1 pin High 
                        `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital  
                        
                    } 
                   
                    /*put in some sort of default */
                    
                }
                
                else //default to interpolation_off 
                {                 
                    `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_1_Write(0); //Drive CFG_1 pin Low
                    `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_2_Write(1); //Drive CFG_2 pin High              
                 
                }    
                break;    
            }
            
            case uSteps:
            {
                if (`$INSTANCE_NAME`_Interpolation == Interpolation_on)
                {
                    if (`$INSTANCE_NAME`_Chopper_mode == spreadCycle)
                    {
                        `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistave pulldown
                        `$INSTANCE_NAME`_CFG_1_Write(0); 
                        `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital                     
                    }
                    
                    else if (`$INSTANCE_NAME`_Chopper_mode == stealthChop)
                    {
                       `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital  
                       `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_DIG_HIZ); //Set pinmode to high impedance digital  
                
                    } 
                   
                    /*put in some sort of default */
                }
                
                else //default to interpolation_off 
                {                 
                    `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_1_Write(1); //Drive CFG_1 pin High
                    `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
                    `$INSTANCE_NAME`_CFG_2_Write(1); //Drive CFG_2 pin High              
                 
                } 
                
                break;     
            }
            
        default:  
            {
               `$INSTANCE_NAME`_Microsteps = Fullstep;
               `$INSTANCE_NAME`_CFG_1_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
               `$INSTANCE_NAME`_CFG_1_Write(0); //Drive CFG_1 pin Low 
               `$INSTANCE_NAME`_CFG_2_SetDriveMode(PIN_DM_RES_DWN); //Set pinmode to resistive pulldown
               `$INSTANCE_NAME`_CFG_2_Write(0); //Drive CFG_2 pin Low 
            }
       }
    
    if (`$INSTANCE_NAME`_Chopper_define == Software_defined)
    {
        `$INSTANCE_NAME`_TMC2100_Chopper_Config(`$INSTANCE_NAME`_Off_time, `$INSTANCE_NAME`_Chopper_hysterisis, `$INSTANCE_NAME`_Blank_time); //Call chopper config function
    }
    
    if (`$INSTANCE_NAME`_Chopper_mode == stealthChop) 
    {
        CyDelay(100); //allow the motor to rest for 100ms as dicated in the TMC2100 datasheet. 
    }
            
       
}


/*******************************************************
                    Chopper Settings 
********************************************************/

void `$INSTANCE_NAME`_TMC2100_Chopper_Config(int `$INSTANCE_NAME`_Off_time, int `$INSTANCE_NAME`_Chopper_hysterisis, int `$INSTANCE_NAME`_Blank_time)
{
    
        /*off time*/ 
        if (`$INSTANCE_NAME`_Off_time == Medium)
        {
            `$INSTANCE_NAME`_CFG_0_SetDriveMode(PIN_DM_RES_DWN); 
            `$INSTANCE_NAME`_CFG_0_Write(1); 
        }
        else if (`$INSTANCE_NAME`_Off_time == High)
        {
            `$INSTANCE_NAME`_CFG_0_SetDriveMode(PIN_DM_DIG_HIZ); 
        }
        else //default to low setting 
        {
            `$INSTANCE_NAME`_CFG_0_SetDriveMode(PIN_DM_RES_DWN); 
            `$INSTANCE_NAME`_CFG_0_Write(0); 
        }
        
        /*Hysteresis*/ 
        if (`$INSTANCE_NAME`_Chopper_hysterisis == Medium)
        {
            `$INSTANCE_NAME`_CFG_4_SetDriveMode(PIN_DM_RES_DWN); 
            `$INSTANCE_NAME`_CFG_4_Write(1); 
        }
        else if (`$INSTANCE_NAME`_Chopper_hysterisis == High)
        {
            `$INSTANCE_NAME`_CFG_4_SetDriveMode(PIN_DM_DIG_HIZ); 
        }
        else //default to low setting 
        {
            `$INSTANCE_NAME`_CFG_4_SetDriveMode(PIN_DM_RES_DWN); 
            `$INSTANCE_NAME`_CFG_4_Write(0); 
        }
        
        
          /*Blank Time*/ 
        if (`$INSTANCE_NAME`_Blank_time == Low)
        {
            `$INSTANCE_NAME`_CFG_5_SetDriveMode(PIN_DM_RES_DWN); 
            `$INSTANCE_NAME`_CFG_5_Write(0); 
        }
        
        else if (`$INSTANCE_NAME`_Blank_time == High)
        {
            `$INSTANCE_NAME`_CFG_5_SetDriveMode(PIN_DM_DIG_HIZ); 
        }
        
        else //default to medium setting 
        {
            `$INSTANCE_NAME`_CFG_5_SetDriveMode(PIN_DM_RES_DWN); 
            `$INSTANCE_NAME`_CFG_5_Write(1); 
        }
        
        
}

int `$INSTANCE_NAME`_TMC2100_Degrees_to_Steps(double degrees, int steps_per_revolution, int `$INSTANCE_NAME`_Microsteps)
{
    double degrees_per_step = 0; 
    int    number_of_steps  = 0;
    
    degrees_per_step = 360.0/steps_per_revolution;
    
     switch (`$INSTANCE_NAME`_Microsteps) 
     {
        case Fullstep:
        {
         
         number_of_steps = round(degrees/degrees_per_step);
       
         break;   
            
        }
        
         case Halfstep:
        {
           
         number_of_steps = round(degrees/(degrees_per_step/2));
         break;  
            
        }
        
        case Quarterstep:
        {
            
         number_of_steps = round(degrees/(degrees_per_step/4));
         break;     
        }
        
        
         case uSteps:
        {
         number_of_steps = round(degrees/(degrees_per_step/16));
         break;     
        }
            
     }
 
return number_of_steps; 
}

CY_ISR(`$INSTANCE_NAME`_TMC_Timer_Interrupt)
{
    `$INSTANCE_NAME`_Step_Write(!`$INSTANCE_NAME`_Step_Read()); //Toggle Step pin 
    
    if (`$INSTANCE_NAME`_toggles != Continous) //if continous operation isn't enabled. 
    {
        `$INSTANCE_NAME`_current_steps++; 
        
        if (`$INSTANCE_NAME`_current_steps == `$INSTANCE_NAME`_toggles)
        {
            `$INSTANCE_NAME`_current_steps = 0; //reset step counter 
            `$INSTANCE_NAME`_toggles = 0;       //reset toggles 
           `$INSTANCE_NAME`_TMC2100_Stop();
        }
    }
   
}


/* [] END OF FILE */

